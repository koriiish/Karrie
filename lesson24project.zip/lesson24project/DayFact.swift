//
//  DayFact.swift
//  lesson24project
//
//  Created by Карина Дьячина on 22.02.24.
//

import Foundation

struct DayFact: Codable {
    let text: String 
}
