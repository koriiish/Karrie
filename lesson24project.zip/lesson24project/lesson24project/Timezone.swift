//
//  TimeZone.swift
//  lesson24project
//
//  Created by Карина Дьячина on 15.02.24.
//

import Foundation
struct Timezone {
    let name: String
    let abbr: String
}
