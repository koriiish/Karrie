//
//  Event.swift
//  lesson24project
//
//  Created by Карина Дьячина on 15.02.24.
//

import Foundation

struct Event {
    let title: String
    let description: String
    let date: String
    }


